package org.example;

import java.util.Arrays;

public class S5 {
    public static void main(String[] args) {
        int N = 5;
        int[] A = {3, 4, 4, 6, 1, 4, 4};
        int[] c = new int[N];

        Arrays.fill(c, 0);

        for(int i = 0; i< A.length; i++)
        {
            int v = A[i];

            if(v >= 1 && v <=N )
            {
                c[v-1] = c[v-1] +1;
            }
            else if(v==N+1)
            {
                maxInd(c);
            }
        }

        //return c;
    }

    private static void maxInd(int[] c)
    {
        int m = c[0];
        for(int i=0; i< c.length ; i++)
        {
            if(m < c[i])
            {
                m = c[i];
            }
        }
        Arrays.fill(c, m);
    }
}
