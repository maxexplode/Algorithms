package org.example;

public class ST {
    public static void main(String[] args) {

        String sA = "89";
        String sB = "764356789";

        //sB.indexOf(sA);

        //System.out.println(sB.indexOf(sA));

        System.out.println(find(sA, sB));

    }

    private static int find(String a, String s) {
        char[] c = a.toCharArray();
        char[] b = s.toCharArray();

        int offset = 0;
        int m = 0;
        for (char value : c) {
            for (int j = offset; j < b.length; j++) {
                if (value == b[j]) {
                    offset = j + 1;
                    ++m;
                    break;
                } else {
                    if (m > 0) {
                        --m;
                    }
                }
            }
            if (m == c.length) {
                return (offset - m);
            }
        }

        return -1;
    }
}
