package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class S6n {
    public static void main(String[] args) {

        int[] A = {0,1,0,1,1};

        int tw = 0;
        int pcars = 0;

        StringBuilder builder = new StringBuilder(A.length);
        Arrays.stream(A).mapToObj(builder::append).count();

        //passing cars

        if(pcars > 1_000_000_000)
        {
            System.out.println(-1);
            //return -1;
        }
        System.out.println(pcars);
        //return pcars;
    }
}
