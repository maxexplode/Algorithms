package org.example;

import java.util.*;

public class S3n {
    public static void main(String[] args) {
        String S = "({{({}[]{})}}[]{})";

        // write your code in Java SE 8
        if (S == null || S.length() == 0) {
            //return 1;
        }

        char[] chars = S.toCharArray();

        List<Character> lkind = Arrays.asList('{', '(', '[');
        List<Character> rkind = Arrays.asList('}', ')', ']');

        ArrayDeque<Character> rchars = new ArrayDeque<>();

        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (rkind.contains(c) || lkind.contains(c)) {
                rchars.add(c);
            }

        }

        int status = 1;

        if (rchars.size() % 2 == 0) {

            for (int i = 0; i < rchars.size() + 1; i++) {
                Character p1 = rchars.pollFirst();
                Character p2 = rchars.pollLast();
                int i1 = lkind.indexOf(p1);
                int i2 = rkind.indexOf(p2);
                if ((i1 == -1 || i2 == -1) || (lkind.indexOf(p1) != i2)) {
                    status = 0;
                }
            }
        } else {
            status = 0;
        }

        System.out.println(status);
    }
}
