package org.example;

import java.util.*;

public class S1 {
    public static void main(String[] args) {
        int[] A = {};
        Map<Integer, Integer> m = new HashMap<>();
        for(int a : A)
        {
            if(m.containsKey(a))
            {
                m.put(a, m.get(a)+1);
            }
            else
            {
                m.put(a, 1);
            }
        }
        for (Map.Entry<Integer, Integer> integerIntegerEntry : m.entrySet()) {
            if(integerIntegerEntry.getValue() == 1)
            {
                //return integerIntegerEntry.getKey();
            }
        }
    }
}
