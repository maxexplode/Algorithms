package org.example;

public class Kadains {
    public static void main(String[] args) {
        int[] A = {-2, -3, 4, -1, -2, 1, 5, -3};

        int maxYet = 0;

        for (int i = 0; i < A.length; i++) {
            int max_sum = 0;
            for (int j = 0; j < i; j++) {


            }
        }

    }
}
