package org.example;

import java.util.Arrays;

public class BubbleSort {
    public static void main(String[] args) {
        int[] unsorted = {12, 45, 63, 231, 13, 7, 56, 91, 73, 34};
        int minIndex = 0;
        for (int i = 0; i < unsorted.length; i++) {
            int min = unsorted[i];
            for (int j = i; j < unsorted.length; j++) {
                if (unsorted[j] > min) {
                    min = unsorted[j];

                    minIndex = j;
                }
            }
            int temp = unsorted[i];
            unsorted[minIndex] = temp;
            unsorted[i] = min;
        }
        System.out.println(Arrays.toString(unsorted));
    }
}
