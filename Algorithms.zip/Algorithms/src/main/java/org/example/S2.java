package org.example;

import java.util.stream.*;

public class S2 {

    public static void main(String[] args) {
        // write your code in Java SE 8
        /*int N = A.length;
        int x = N-1;

        int[] sum = new int[x];

        for(int i=1; i<=x ; i++)
        {
            int[] f = d(A, 0, i);
            int[] s = d(A, i, N);

            //System.out.println( "f " + Arrays.toString(f) + " s " + Arrays.toString(s));

            sum[i-1] = Math.abs(IntStream.of(f).sum() - IntStream.of(s).sum());

        }
        Arrays.sort(sum);*/
    }
}
