package org.example;

import java.util.Arrays;

public class S4 {
    public static void main(String[] args) {

        int[] A = {2, 1, 2, 8, 2};
        int X = 2;

        int[] s = new int[2];

        Arrays.fill(s, 0);

        s[0] = 1;

        for(int i = 0; i< A.length; i++ )
        {
            if(X > A[i]) {
                s[A[i]] = 1;
            }
            if(sum(s) == X)
            {
                System.out.println(i);
                break;
            }
        }

        System.out.println(-1);
    }

    private static int sum(int[] a)
    {
        int s = 0;
        for (int c: a)
        {
            s+=c;
        }
        return s;
    }
}
