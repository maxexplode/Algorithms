package org.example;

import java.util.ArrayList;
import java.util.List;

public class PrimeNumbers {
    public static void main(String[] args) {
        int K = 100;
        List<Integer> primes = new ArrayList<>();
        primes.add(2);
        for (int i = 3; i <= K; i++) {
            double r = Math.sqrt(i);
            if (r % 1 != 0) {
                int d = 0;
                for (Integer prime : primes) {
                    if (i % prime == 0) {
                        d = 1;
                        break;
                    }
                }
                if (d != 1) {
                    primes.add(i);
                }
            }
        }
        System.out.println(primes);
    }
}
