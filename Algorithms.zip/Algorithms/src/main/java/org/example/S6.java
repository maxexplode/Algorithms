package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class S6 {
    public static void main(String[] args) {

        int[] A = {0,1,0,1,1,1};
        Map<Integer, List<Integer>> cars = new HashMap<>();
        for(int i = 0; i< A.length; i++)
        {
            cars.computeIfAbsent(A[i], a-> new ArrayList<>());
            cars.get(A[i]).add(i);
        }

        //passing cars

        int pcars = 0;

        if(cars.size() == 2)
        {
            for(Integer e : cars.get(1))
            {
                for(Integer w : cars.get(0))
                {
                    if(e > w)
                    {
                        ++pcars;
                    }
                }
            }
        }

        if(pcars > 1_000_000_000)
        {
            System.out.println(-1);
            //return -1;
        }
        System.out.println(pcars);
        //return pcars;
    }
}
