package org.example;

import java.util.concurrent.CountDownLatch;

public class Zoo {
    public static void main(String[] args) {

        ZooInternal zooInternal = new ZooInternal();

        Runnable r = () -> {
            zooInternal.empty();
            zooInternal.clean();
            zooInternal.restore();
        };

        Thread thread1 = new Thread(r, "worker 1");
        Thread thread2 = new Thread(r, "worker 2");
        Thread thread3 = new Thread(r, "worker 3");
        Thread thread4 = new Thread(r, "worker 4");

        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();

    }

    static class ZooInternal {

        final CountDownLatch empty = new CountDownLatch(4);
        final CountDownLatch clean = new CountDownLatch(4);
        final CountDownLatch restore = new CountDownLatch(4);


        public ZooInternal() {
        }

        private void empty() {
            synchronized (this) {
                empty.countDown();
                System.out.println(Thread.currentThread().getName() + " empty");
            }
        }

        private void clean() {
            synchronized (empty) {
                try {
                    empty.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            synchronized (this) {
                clean.countDown();
                System.out.println(Thread.currentThread().getName() + " clean");
            }
        }

        private void restore() {
            synchronized (clean) {
                try {
                    clean.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            synchronized (this) {
                restore.countDown();
                System.out.println(Thread.currentThread().getName() + " restore");
            }
        }
    }

    interface Task extends Runnable {
        @Override
        default void run() {

            try {
                doTask();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        void doTask() throws Exception;
    }

    static class EmptyTask implements Task {

        private final ZooInternal zooInternal;

        public EmptyTask(ZooInternal zooInternal) {
            this.zooInternal = zooInternal;
        }

        @Override
        public void doTask() throws Exception {
            System.out.println("Emptying..." + Thread.currentThread().getName());
            zooInternal.empty();
            Thread.sleep(1000);
        }
    }

    static class CleaningTask implements Task {

        private final ZooInternal zooInternal;

        public CleaningTask(ZooInternal zooInternal) {
            this.zooInternal = zooInternal;
        }

        @Override
        public void doTask() throws Exception {
            System.out.println("Cleaning..." + Thread.currentThread().getName());
            zooInternal.clean();
            Thread.sleep(2000);
        }
    }

    static class RestoreTask implements Task {

        private final ZooInternal zooInternal;

        RestoreTask(ZooInternal zooInternal) {
            this.zooInternal = zooInternal;
        }

        @Override
        public void doTask() throws Exception {
            System.out.println("Restoring..." + Thread.currentThread().getName());
            zooInternal.restore();
            Thread.sleep(1000);
        }
    }
}
