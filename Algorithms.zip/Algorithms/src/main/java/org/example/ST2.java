package org.example;

import java.util.*;
import java.util.stream.IntStream;

public class ST2 {
    /*public String solution(String message, int K) {
        // write your code in Java SE 8
        if (K < 1) {
            return "";
        }

        if (K >= message.length()) {
            return message;
        }

        String b = message.substring(0, K).stripTrailing();

        if (b.length() == K) {
            if (' ' != message.charAt(K)) {
                int ld = b.lastIndexOf(' ');
                return ld == 1 ? "" : b.substring(0, ld);
            }
        }

        return b;
    }

    public int solution(int[] A) {
        int n = A.length;
        if (n == 1) {
            return 0;
        }

        Integer[] a1 = IntStream.of(A).boxed().toArray(Integer[]::new);

        Arrays.sort(a1, Collections.reverseOrder());

        if (n == 2) {
            if ((a1[0] - a1[1]) == 1) {
                return 1;
            }
            return 0;
        }
        int sum = 0;
        int cr = a1[0];
        for (int i = 0; i < n; i++) {

            if ((cr - a1[i]) == 1) {
                sum++;
                continue;
            }
            if ((cr - a1[i]) > 1) {
                cr = a1[i - 1];
                if ((cr - a1[i]) == 1) {
                    sum++;
                }
            }
        }

        return sum;

    }*/

    /*public static void main(String[] args) {
        Random random = new Random();
        int[] A  = new int[100_000];
        Arrays.fill(A, random.nextInt(1_000_000_000 - 2 ) -2);
        long currentTimeMillis = System.currentTimeMillis();
        int n = A.length;
        if (n == 1) {
            System.out.println(0);
        }

        Integer[] a1 = IntStream.of(A).boxed().toArray(Integer[]::new);

        Arrays.sort(a1, Collections.reverseOrder());

        if (n == 2) {
            if ((a1[0] - a1[1]) == 1) {
                System.out.println(1);
            }
            System.out.println(0);
        }
        int sum = 0;
        int cr = a1[0];
        for (int i = 0; i < n; i++) {

            if ((cr - a1[i]) == 1) {
                sum++;
                continue;
            }
            if ((cr - a1[i]) > 1) {
                cr = a1[i - 1];
                if ((cr - a1[i]) == 1) {
                    sum++;
                }
            }
        }

        System.out.println(sum);
        System.out.println( (System.currentTimeMillis() - currentTimeMillis) + "ms" );
    }*/



    public static void main(String[] args) {

        //int[] A  = {3, 4,3, 0, 2,2,3,0,0};
        //int[] A  = {4, 4, 3,3,1,0};
        Random random = new Random();

        int[] A  = new int[100_000];
        Arrays.fill(A, random.nextInt(1_000_000_000 - 2 ) -2);
        //int[] A  = {3, 4,3, 0, 2,2,3,0,0};
        long currentTimeMillis = System.currentTimeMillis();
        Map<Integer, List<Integer>> map = new HashMap<>();
        for(int a : A)
        {
            map.computeIfAbsent( a , s -> new ArrayList<>());
            map.get(a).add(a);
        }
        int sum = 0;

        for (Integer rank : map.keySet()) {
            if(map.containsKey(rank +1))
            {
                sum = sum + map.get(rank).size();
            }
        }



        System.out.println(sum);

        System.out.println( (System.currentTimeMillis() - currentTimeMillis) + "ms" );
    }
}
