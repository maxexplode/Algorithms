package org.example;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

public class Solution {
    public static void main(String[] args) throws IOException {

        int[][] A = {
                {1,1,1,0,0,0},
                {0,1,0,0,0,0},
                {1,1,1,0,0,0},
                {0,0,0,0,0,0},
                {0,0,0,0,0,0},
                {0,0,0,0,0,0},
        };

        int l = 4;
        int x = 4;

        int n = A[0][0] + A[0][1]  + A[0][2] + A[1][1] + A[2][0] + A[2][1] + A[2][2];
        //System.out.println("f " + n);

        for (int i = 0; i < l; i++) {
            int r = 0;
            for (int j = 0; j < x; j++) {
                r = A[i][j] + A[i][j+1] + A[i][j+2] + A[i+1][j+1] + A[i+2][j] + A[i+2][j+1] + A[i+2][j+2];
                System.out.println(r);
            }
        }
    }
}
