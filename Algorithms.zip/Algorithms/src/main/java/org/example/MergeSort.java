package org.example;

import java.util.Arrays;

public class MergeSort {
    public static void main(String[] args) {
        int[] unsorted = {5, 3, 7, 9, 1, 4, 5, 0};

        divideArray(unsorted, 0, unsorted.length - 1);
    }

    private static void divideArray(int[] arr, int s, int e) {

        if (s < e) {
            int m = (s + e) / 2;
            divideArray(arr, s, m);
            divideArray(arr, m + 1, e);
            join(arr, s, m, e);
        }
    }

    private static void join(int[] arr, int s, int m, int e) {

        int la = 1 + (m - s);
        int lb = e - m;

        int[] a = new int[la];
        int[] b = new int[lb];

        System.arraycopy(arr, s, a, 0, a.length);
        System.arraycopy(arr, m+1, b, 0, b.length);

        int i = 0;
        int j = 0;

        int p = 0;

        while (i < la && j < lb) {
            if(b[j] <= a[i])
            {
                arr[p] = b[j];
                j++;
            }
            else
            {
                //arr[p] = a[i];
                i++;
            }
            p++;
        }

        while(i < la)
        {
            arr[p] = a[i];
            i++;
            p++;
        }

        while(j < lb)
        {
            arr[p] = b[j];
            j++;
            p++;
        }

        System.out.println(Arrays.toString(arr));
    }
}
