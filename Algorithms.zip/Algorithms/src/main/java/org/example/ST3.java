package org.example;

public class ST3 {
    public static void main(String[] args) {
        String sent = "Codility we test orders";

        int  K = 14;

        String substring = sent.substring(0, K);

        while(!substring.endsWith(" "))
        {
            substring = substring.substring(0, substring.length()-1);
        }

        System.out.println(substring.trim());
    }
}
