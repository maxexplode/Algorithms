package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.IntStream;

public class ST1 {

    public static void main(String[] args) {
        int[] x = {3,2,6,-1,4,5,-11, 2};
        System.out.println(s(x));
    }

    public static int s(int[] A) {

        int n = A.length;
        if(n == 1)
        {
            return 0;
        }

        Integer[] a1 = IntStream.of(A).boxed().toArray(Integer[]::new);

        Arrays.sort(a1, Collections.reverseOrder());

        if(n==2)
        {
            if((a1[0] - a1[1]) == 1)
            {
                return 1;
            }
            return 0;
        }
        int sum = 0;
        int cr = a1[0];
        for (int i = 0; i < n; i++) {

            if((cr - a1[i]) == 1)
            {
                sum++;
                continue;
            }
            if((cr - a1[i]) > 1)
            {
                cr = a1[i-1];
                if((cr - a1[i]) == 1)
                {
                    sum++;
                }
            }
        }

        return sum;
    }

}
