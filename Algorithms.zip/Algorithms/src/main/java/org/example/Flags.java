package org.example;

import java.util.ArrayList;
import java.util.List;

public class Flags {
    public static void main(String[] args) {
        int A[] = {1, 5, 3, 4, 3, 4, 1, 2, 3, 4, 6, 2};

        int p = A[0];
        int s = A[0];
        int n= 0;
        List<Integer> peeks = new ArrayList<>();
        for(int i = 1; i< A.length; i++)
        {
            int t = A[i];

            if(t > s)
            {
                ++n;
                p = t;
            }
            else if ( s <= p)
            {
                System.out.println(s);
                s = t;
            }
        }
    }
}
