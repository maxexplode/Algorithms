package org.example;

public class CountFactors {

    public static void main(String[] args) {
        //int N = Integer.MAX_VALUE;
        int N = 24;
        int f = 0;
        for(long i=1; i<= N; i++ )
        {
            if( N%i == 0 )
            {
                ++f;
            }
        }
        System.out.println(f);
    }
}
