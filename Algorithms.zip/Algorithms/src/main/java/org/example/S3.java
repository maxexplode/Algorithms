package org.example;

import java.util.*;

public class S3 {
    public static void main(String[] args) {
        String S = "())(()";

        // write your code in Java SE 8
        if(S==null || S.length() == 0)
        {
            //return 1;
        }

        char[] chars = S.toCharArray();

        List<Character> lkind = Arrays.asList('{', '(', '[');
        List<Character> rkind = Arrays.asList('}', ')', ']');

        Stack<Character> lchars = new Stack<>();
        Queue<Character> rchars = new ArrayDeque<>();

        for (int  i= 0; i< chars.length ;i++) {
            char c = chars[i];
            if(i == 0 && rkind.contains(c))
            {
                //return 0;
            }
            if (lkind.contains(c)) {
                lchars.push(c);
            } else if (rkind.contains(c)) {
                rchars.add(c);
            }

        }


        int status = 1;

        if (lchars.size() == rchars.size()) {
            for (int i = 0; i < lchars.size() + 1; i++) {
                Character p1 = lchars.pop();
                Character p2 = rchars.poll();
                if (!rkind.get(lkind.indexOf(p1)).equals(p2)) {
                    status = 0;
                }
            }
        } else {
            status = 0;
        }

        System.out.println(status);
    }
}
