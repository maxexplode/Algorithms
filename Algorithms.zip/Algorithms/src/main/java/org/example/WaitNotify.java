package org.example;

import java.util.concurrent.TimeUnit;

public class WaitNotify {
    public static void main(String[] args) {
        StringBuilder a = new StringBuilder();

        Thread t1 = new Thread() {
            @Override
            public void run() {
                while(true) {
                    a.append("t-1");
                    try {
                        TimeUnit.SECONDS.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        t1.start();

        Thread t2 = new Thread() {
            @Override
            public void run() {
                while(true) {
                    a.append("t-2");
                    try {
                        TimeUnit.SECONDS.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        t2.start();

        while (true)
        {


            try {
                synchronized (a)
                {
                    //a.wait();
                    System.out.println(a.toString());
                    a.notifyAll();
                    TimeUnit.SECONDS.sleep(3);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    class soi
    {
        private String s = "";

        private boolean st = false;

        public void setS(String s) {
            this.s = s;
        }

        public String getS() {
            return s;
        }
    }
}
